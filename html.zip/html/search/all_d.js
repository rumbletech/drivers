var searchData=
[
  ['sense_5fboth_5fedges',['SENSE_BOTH_EDGES',['../GPIO_8h.html#aac1670a58a22de6af7ddd5aecf55bfe7ad91241caa6947fa0e6e782aefef877a0',1,'GPIO.h']]],
  ['sense_5ffalling_5fedge',['SENSE_FALLING_EDGE',['../GPIO_8h.html#aac1670a58a22de6af7ddd5aecf55bfe7a550c0eb375f910fbedcc2577d5b3025c',1,'GPIO.h']]],
  ['sense_5finput_5fdisabled',['SENSE_INPUT_DISABLED',['../GPIO_8h.html#aac1670a58a22de6af7ddd5aecf55bfe7af9d31e66221110d5c2a3da3eabc44b75',1,'GPIO.h']]],
  ['sense_5flevel',['SENSE_LEVEL',['../GPIO_8h.html#aac1670a58a22de6af7ddd5aecf55bfe7ac496f686928334d52e4487dfe153f668',1,'GPIO.h']]],
  ['sense_5frising_5fedge',['SENSE_RISING_EDGE',['../GPIO_8h.html#aac1670a58a22de6af7ddd5aecf55bfe7a697aff4f0d46f4eb25b34167aa9f8e40',1,'GPIO.h']]],
  ['sleep_5fstruct',['SLEEP_struct',['../structSLEEP__struct.html',1,'']]],
  ['spi_5fstruct',['SPI_struct',['../structSPI__struct.html',1,'']]]
];
