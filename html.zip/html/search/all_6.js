var searchData=
[
  ['hires_5fstruct',['HIRES_struct',['../structHIRES__struct.html',1,'']]]
];
