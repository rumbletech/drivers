var searchData=
[
  ['sleep_5fstruct',['SLEEP_struct',['../structSLEEP__struct.html',1,'']]],
  ['spi_5fstruct',['SPI_struct',['../structSPI__struct.html',1,'']]]
];
